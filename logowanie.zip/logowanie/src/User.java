public abstract class User {
    // Metoda abstrakcyjna, którą będą nadpisywać klasy pochodne
    public abstract String getAccessLevel();
}
