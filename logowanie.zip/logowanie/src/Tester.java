public class Tester extends User {
    @Override
    public String getAccessLevel() {
        return "Dostęp do środowiska testowego";
    }
}
