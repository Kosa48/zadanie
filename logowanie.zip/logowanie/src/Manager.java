public class Manager extends User {
    @Override
    public String getAccessLevel() {
        return "Dostęp do raportów";
    }
}
