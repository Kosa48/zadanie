public class Programmer extends User {
    @Override
    public String getAccessLevel() {
        return "Dostęp do kodu";
    }
}
